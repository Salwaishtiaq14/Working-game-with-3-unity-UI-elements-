﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct Damag
{
    public Vector3 origin;
    public int damageAmount;
    public float pushForce;
}
